PyObject *xmlsec_xmlsec_version(PyObject *self, PyObject *args);
PyObject *xmlsec_xmlsec_version_major(PyObject *self, PyObject *args);
PyObject *xmlsec_xmlsec_version_minor(PyObject *self, PyObject *args);
PyObject *xmlsec_xmlsec_version_subminor(PyObject *self, PyObject *args);
PyObject *xmlsec_xmlsec_version_info(PyObject *self, PyObject *args);
