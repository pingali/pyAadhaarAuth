PyObject *xmlsec_TransformMemBufId(PyObject *self, PyObject *args);
PyObject *xmlsec_TransformMemBufGetBuffer(PyObject *self, PyObject *args);
