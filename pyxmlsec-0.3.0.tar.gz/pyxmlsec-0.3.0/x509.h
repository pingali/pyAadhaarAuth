PyObject *xmlsec_X509DataGetNodeContent(PyObject *self, PyObject *args);
