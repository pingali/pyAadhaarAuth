PyObject *xmlsec_ErrorsSetCallback(PyObject *self, PyObject *args);
