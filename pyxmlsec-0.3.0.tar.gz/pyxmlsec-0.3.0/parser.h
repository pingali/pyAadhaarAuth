PyObject *xmlsec_ParseFile(PyObject *self, PyObject *args);
PyObject *xmlsec_ParseMemory(PyObject *self, PyObject *args);
PyObject *xmlsec_ParseMemoryExt(PyObject *self, PyObject *args);
PyObject *xmlsec_TransformXmlParserId(PyObject *self, PyObject *args);
